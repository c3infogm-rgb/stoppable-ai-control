# AMS-SEED COVID (Sim) — Audit-First Result Pack

- Windows: 1262 days (2020-01-16 → 2023-06-30)
- TG HOLD days: 54 (first HOLD: 2023-05-08)
- IDF mode counts: NORMAL=988, RECOVER=191, FREEZE=83

## Highlight
- Measurement-spec change simulated at **2023-05-08** → `new_cases` becomes missing → TG enforces HOLD.

## Files
- covid_seed_idf_timeline.csv
- covid_seed_mil_packets.jsonl
- covid_seed_tg_audit.jsonl
- covid_seed_run_manifest.json
- covid_seed_worm_log.jsonl
- covid_seed_metrics.json
- covid_seed_conformance.json
- covid_seed_undefined_report.json
